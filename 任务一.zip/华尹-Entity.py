# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load
import codecs
import json

import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os

from tensorflow.python.keras.callbacks import ModelCheckpoint

for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session


import tensorflow as tf
try:
    # detect and init the TPU
    tpu = tf.distribute.cluster_resolver.TPUClusterResolver.connect()
    # instantiate a distribution strategy
    tpu_strategy = tf.distribute.experimental.TPUStrategy(tpu)
except:
    tpu = None


'''
    -----------------------  import block  --------------------
'''

import re
import warnings
import gc
import jieba
import pandas as pd
import numpy as np
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences

from sklearn.model_selection import KFold
from tensorflow.python.keras.utils.np_utils import to_categorical

from gensim.models import Word2Vec, FastText
import multiprocessing


import tensorflow as tf

from tensorflow.python.keras import Input
from keras.callbacks import *
from tensorflow.python.keras.layers import TimeDistributed, Embedding, Bidirectional, LSTM, Lambda, Conv1D, Concatenate, Dense, GlobalAveragePooling1D

from keras.initializers import *
import matplotlib.pyplot as plt
from tensorflow.keras.optimizers import Adam
from keras.layers import *

import ast

from transformers import BertTokenizer, BertModel
import torch
from keras.models import Model

warnings.filterwarnings('ignore')




'''
    -----------------------  config  ---------------------------
'''
pre_path = '/kaggle/input/sohu2019-data'
tmp_path = '/kaggle/working'
result_path = '/kaggle/working'

pre_inp = '/kaggle/input'
pre_bert = 'hfl/chinese-bert-wwm-ext'
pre_work = tmp_path
h5_path = tmp_path

# pre_bert = './data/bert'  # 本地路径
# pre_path = './data'
# tmp_path = './models/sohu'

vocab_path = pre_bert + '/vocab.txt'
config_path = pre_bert + '/bert_config.json'
checkpoint_path = pre_bert + '/bert_model.ckpt'
save_model_path = pre_work + '/bert_bilstm_150.h5'


word2vec_path = tmp_path + '/w2v.model'
fasttext_path = tmp_path + '/fasttext.model'

saved_result_path = result_path + '/result.csv'


user_dict_path = pre_path + '/userdict.txt'
# 给结巴分词导入自定义用户词典
# jieba.load_userdict(user_dict_path)

MAXLEN = 170
BATCH_SIZE = 32
N_CLASS = 4
VOCAB_SIZE = 2


class KeyConfig:
    KEY_LABEL = 'coreEntityEmotions'
    KEY_CONTENT = 'content'
    KEY_TITLE = 'title'
    KEY_ID = 'newsId'
    KEY_TEXT = 'text'


class EmbeddingConf:
    word2vec_dim = 100
    fasttext_dim = 100
    bert_dim = 768


class FileConfig:
    train_path = pre_path + '/train.txt'
    test_path = pre_path + '/test.txt'
    all_simplify = result_path + '/sohu_all_text.csv'


class ModelConf:
    optimizer = Adam(2e-4)
    batch_size = 16
    epochs = 20


CONFIG = KeyConfig()




'''
    ----------------  model class  ------------------
'''

class CallConfig:
    def __init__(self, filePath):
        self.filepath = filePath

class BiLSTM_MCnn:

    def __init__(self, em_matrix):

        if tpu is not None:
            # instantiating the model in the strategy scope creates the model on the TPU
            with tpu_strategy.scope():
                self.__base_model(em_matrix)
                self.__mix_model()
        else:
            self.__base_model(em_matrix)
            self.__mix_model()

    def __base_model(self, em_matrix):
        self.emConf = EmbeddingConf()
        self.modConf = ModelConf()

        sequence = Input(shape=(MAXLEN,), dtype='float32')
        self.sequence = sequence

        embedding_layer = Embedding(em_matrix.shape[0], em_matrix.shape[1],weights=[em_matrix], input_length=MAXLEN, trainable=False, mask_zero=True)

        em_layer = embedding_layer(sequence)        
        mask = Masking(mask_value=0.)(em_layer)
        spat = SpatialDropout1D(0.2)(mask)
        self.spat = spat

        
    def __BiLSTM__(self):
        blstm = Bidirectional(LSTM(256, return_sequences=True), merge_mode='sum')(self.spat)
        dropout = Dropout(0.3)(blstm)
        blstm = Bidirectional(LSTM(128, return_sequences=True), merge_mode='sum')(dropout)
        dropout = Dropout(0.3)(blstm)
        blstm = Bidirectional(LSTM(64, return_sequences=True), merge_mode='sum')(dropout)
        dropout = Dropout(0.3)(blstm)
        blstm = Bidirectional(LSTM(32, return_sequences=True), merge_mode='sum')(dropout)
        dropout = Dropout(0.3)(blstm)
        
        self.bil_layer = dropout

    def __mix_model(self):
        self.__BiLSTM__()
        _outputs = TimeDistributed(Dense(N_CLASS, kernel_initializer=tf.keras.initializers.Orthogonal(seed=2021), activation='softmax'))(self.bil_layer)
        self.model = Model(inputs=self.sequence, outputs=_outputs)


    def __add_callbacks(self, callsConfig):
        checkpoint = ModelCheckpoint(filepath=callsConfig.filepath,
                                     monitor='val_loss',
                                     verbose=1, save_best_only=True)

        self.callbacks = [checkpoint]


    def __compile_model(self):
        self.model.compile(
            loss='categorical_crossentropy',
            optimizer=self.modConf.optimizer,
            metrics=['acc'])
        self.model.summary()  # 输出模型各层的参数状况


    def __fit_model__(self, train_x, train_y, valid_x, valid_y):
        self.history = self.model.fit(
            train_x,
            train_y,
            validation_data=(valid_x, valid_y),
            epochs=self.modConf.epochs,
            batch_size=self.modConf.batch_size,
            callbacks=self.callbacks
        )

    def __plot__(self):
        s, (one, two) = plt.subplots(2, 1)

        one.plot(self.history.history['acc'], c='b')
        one.plot(self.history.history['val_acc'], c='r')
        one.set_title('Model Accuracy')
        one.set_ylabel("accuracy")
        one.set_xlabel("epoch")
        one.legend(['LSTM train', 'LSTM val'], loc='upper left')

        two.plot(self.history.history['loss'], c='m')
        two.plot(self.history.history['val_loss'], c='c')
        two.set_title('Model Loss')
        two.set_ylabel('loss')
        two.set_xlabel('epoch')
        two.legend(['train', 'val'], loc='upper left')

    def run(self, X_train, Y_train, X_valid, Y_valid, callsConfig):
        print(' ---------------  fit model  ---------------')

        self.__compile_model()
        self.__add_callbacks(callsConfig=callsConfig)
        self.__fit_model__(X_train, Y_train, X_valid, Y_valid)

        print(' ---------------  complete fit  ---------------')

        self.__plot__()

    def pred(self, x_data):
        return self.model.predict(x_data)


'''
    -------------------------  utils -------------------
'''


# 读取数据
def readData(filePath):
    f = codecs.open(filePath, 'r', 'utf-8')
    data = []
    for line in f.readlines():
        '''
            鉴于文本以json格式存储，需调用json库进行反序列化
        '''
        news = json.loads(line.strip())
        data.append(news)
    return pd.DataFrame(data)

# 分词
def cutText(text):
    result = []
    for x in list(jieba.cut(text)):
        if len(x) != 1:
            result.append(x)
    return result


# 清洗数据
def filterText(text):
    """
    清洗 text 数据
    :param text: source string
    :return: string
    """
    cleaner = re.compile('<[^>]+>', re.S)
    text = re.sub(cleaner, '', text)
    text = text.lower()
    text = cutText(text)
    return text


'''
    ---------------------- model relative --------------------
'''


# 构建分词器
def create_Token(all_data):
    # 创建分词器 Tokenizer 对象
    _tokenizer = Tokenizer(num_words=None)
    _tokenizer.fit_on_texts(all_data)
    return _tokenizer

# 构建 embedding 层
def gen_emb_matrix(_tokenizer, all_text):

    print('---------------------  构建 embedding  -------------------')


    print('---------------------  构建 bert  -------------------')
    
    # bert_m_path = '/kaggle/working/bert_matrix.npy'
    emb_bert = gen_emb_by_strategy(_tokenizer, all_text, 'BERT')
        
    print('emb_bert.shape:', emb_bert.shape)
    
    print('---------------------  构建 word2vec  -------------------')
    
    # w2v_m_path = '/kaggle/working/w2v_matrix.npy'
    emb_w2v = gen_emb_by_strategy(_tokenizer, all_text, 'W2V')    
    print('emb_w2v.shape:', emb_w2v.shape)


    print('---------------------  构建 fastext  -------------------')
    
    # fast_m_path = '/kaggle/working/fast_matrix.npy'
    emb_fast = gen_emb_by_strategy(_tokenizer, all_text, 'FAST')
    print('emb_fast.shape:', emb_fast.shape)


    print('---------------------  拼接  -------------------')

    emb_matrix = np.concatenate([emb_bert, emb_w2v, emb_fast], axis=1)  # 拼接三个词向量


    print('---------------------  embedding 构建✅  -------------------')
    print('emb_shape:', emb_matrix.shape)
    np.save('/kaggle/working/emb.npy', emb_matrix)

    return emb_matrix

# 根据不同策略生成embedding
def gen_emb_by_strategy(_tokenizer, all_text, key):
    '''
        @key: 'BERT' | 'W2V' | 'FAST'
    '''
    EMC = EmbeddingConf()
    index_word = _tokenizer.index_word
    word_index = _tokenizer.word_index


    if key == 'BERT':
        bert_tokenizer = BertTokenizer.from_pretrained(pre_bert)
        bert_model = BertModel.from_pretrained(pre_bert)

        emb_bert = np.zeros((1 + len(index_word.values()), EMC.bert_dim))
        for i, word in index_word.items():
            inputs = bert_tokenizer(word, return_tensors='pt', padding='max_length', truncation=True, max_length=1)
            emb_bert[i] = bert_model(**inputs)[1].detach().numpy()
        
        return emb_bert
    
    elif key == 'W2V':
        model = Word2Vec(all_text, size=EMC.word2vec_dim, min_count=1, workers=20, iter=20, window=5)
        emb = np.zeros((len(word_index) + 1, EMC.word2vec_dim))
    elif key == 'FAST':
        model = FastText(all_text, size=EMC.fasttext_dim, min_count=1, workers=20, iter=20, window=5)  # 训练fasttext模型
        emb = np.zeros((len(word_index) + 1, EMC.fasttext_dim))

    for word, i in word_index.items():
        if word in model:
            emb[i] = model[word]

    return emb



'''
    -----------------   GET - Data   -----------------
'''

def get_data():
    print('------------ get data -------------')
    file_meta = FileConfig()
    train_data = readData(file_meta.train_path).head(1000)
    test_data = readData(file_meta.test_path).head(1000)
    
    train_data[CONFIG.KEY_LABEL] = train_data[CONFIG.KEY_LABEL].apply(
        lambda ce: dict([(d['entity'], d['emotion']) for d in ce]))
    test_data[CONFIG.KEY_LABEL] = ''

    all_data = pd.concat([train_data, test_data], ignore_index=True)
    
    all_data[CONFIG.KEY_TEXT] = all_data[CONFIG.KEY_TITLE]+' '+all_data[CONFIG.KEY_CONTENT]
    all_data[CONFIG.KEY_TEXT]  = all_data[CONFIG.KEY_TEXT].map(lambda x: filterText(x))
    
    print(' ---------------- train_data.len: ----------------\n', len(train_data))
    print(' ---------------- test_data.len: ----------------\n', len(train_data))


    train_data = all_data[[CONFIG.KEY_ID,CONFIG.KEY_LABEL,CONFIG.KEY_TEXT]].head(len(train_data)).reset_index(drop=True)
    test_data = all_data[[CONFIG.KEY_ID,CONFIG.KEY_LABEL,CONFIG.KEY_TEXT]].tail(len(test_data)).reset_index(drop=True)
    text = pd.concat([train_data[CONFIG.KEY_TEXT],test_data[CONFIG.KEY_TEXT]],ignore_index=True)


    print(' ---------------- train_data.head: ----------------\n', train_data.head())
    print(' ---------------- test_data.head: ----------------\n', test_data.head())

    return train_data, test_data, text

# 数据打标
def get_label(train_data, sequences, index_word):
    POS = [0, 1, 0, 0]
    NEG = [0, 0, 1, 0]
    NET = [0, 0, 0, 1]
    NOR = [1, 0, 0, 0]

    data_label = []
    for i, seq in enumerate(sequences):
        label = []
        EntityEmotions = train_data.loc[i, CONFIG.KEY_LABEL]
        for s in seq:
            '''
                判断s是否是填充的0值 并且 判断当前词语是否是实体词标签
            '''
            if s != 0 and index_word[s] in EntityEmotions.keys():
                '''
                    通过对标签的分类 添加相应的label向量
                '''
                entities = {
                    'NEG': NEG,
                    'POS': POS,
                }
                label.append(entities.get(EntityEmotions[index_word[s]], NET))
            else:
                label.append(NOR)
        data_label.append(label)
    return np.array(data_label)




'''
    --------------------------  predict relative  -----------------------
'''

# 计算得分
def get_socre(true_data, pred_data):
    emotions_score = 0
    entity_score = 0
    for i in true_data.index:        
        true = true_data.iloc[i]
        pred = pred_data.iloc[i]

        emotions_score += __f1_score(
            [entity + '_' + emotions for entity, emotions in zip(pred['entity'], pred['emotion'])],
            [entity + '_' + emotions for entity, emotions in zip(true['entity'], true['emotion'])]
        )

        entity_score += __f1_score(pred['entity'], true['entity'])
    entity_score /= len(true_data)  # 实体分数
    emotions_score /= len(true_data)  # 实体情感分数
    score = (entity_score + emotions_score) / 2  # 总分数
    print('score =', score)
import heapq

def __f1_score(pred, true):
    n = len(list(set(pred) & set(true)))
    f1 = 0
    if n != 0:
        '''
            只有 n 有效时，才可正确计算f1
        '''
        recall = n / len(true)
        precision = n / len(pred)
        f1 = 2 * precision * recall / (precision + recall)
    return f1
 
    
def __select_entity(entity_dict, pro):
    entity_series = pd.Series(list(entity_dict.values()), index=list(entity_dict.keys()))

    len_entity = len(entity_series[entity_series < pro])

    if len_entity == 0:
        return [entity_series.idxmin()]
    elif len_entity >= 1 and len_entity <= 3:
        return [k for k in entity_series.index if entity_series[k] < pro]
    else:
        return [list(entity_series.index)[list(entity_series).index(x)] for x in heapq.nsmallest(3, entity_series)]

# 结果后处理
def result_deal(probs, X_test, index_word, pro):

    POS = 'POS'
    NEG = 'NEG'
    NOR = 'NORM'

    is_entity_probs = pd.DataFrame(probs[:, :, 0])  # 非实体词概率

    entity_list = []
    emotion_list = []

    '''
        取出第i行样本非实体词概率,并生成实体词字典：
        key：词语下标，value：词语的非实体词概率
    '''
    for i in is_entity_probs.index:
        
        is_entity_prob = is_entity_probs.iloc[i]
        is_entity_dict = dict(zip(is_entity_prob.index, is_entity_prob))

        '''
            删除用0填充的词语key-value
        '''
        for j in is_entity_prob.index:
            if X_test[i][j] == 0:
                is_entity_dict.pop(j)

        res = __select_entity(is_entity_dict, pro)

        entity = []
        emotion = []
        for r in res:
            word = index_word[X_test[i][r]]
            if word not in entity:
                entity.append(word)
                possibility = probs[i][r][1:]

                if np.argmax(possibility) == 1:
                    emotion.append(NEG)
                elif np.argmax(possibility) == 0:
                    emotion.append(POS)
                else:
                    emotion.append(NOR)

        entity_str = ','.join(entity)
        emotion_str = ','.join(emotion)

        entity_list.append(entity_str)
        emotion_list.append(emotion_str)

    return entity_list, emotion_list





'''
    -----------------------  skf train  ------------------------
'''

def skf(em_matrix,
        x_train,
        y_train,
        x_test,
        n_splits=5):

    _skf = KFold(n_splits=n_splits, shuffle=True).split(x_train)

    _train_pred = np.zeros((x_train.shape[0], MAXLEN, N_CLASS))
    _test_pred = np.zeros((x_test.shape[0], MAXLEN, N_CLASS))

    for i, (train_index, valid_index) in enumerate(_skf):
        print("--------------------  n@:{}fold  ------------------".format(i + 1))

        _x_train, _y_train = x_train[train_index], y_train[train_index]
        
        model = BiLSTM_MCnn(em_matrix=em_matrix)

        _x_valid, _y_valid = x_train[valid_index], y_train[valid_index]

        model.run(
            X_train=_x_train,
            Y_train=_y_train,
            X_valid=_x_valid,
            Y_valid=_y_valid,
            callsConfig=CallConfig(h5_path + '/BiLSTM_{}.h5'.format(i + 1))
        )

        _train_pred[valid_index] = model.pred(_x_valid)
        _test_pred += model.pred(x_test) / n_splits


    return _train_pred, _test_pred, model



'''
    ----------------------------- run ---------------------------
'''

# TODO:
#  6. 预测


print('--------------------- 获取数据  ---------------------')

trainData, testData, allText = get_data()


print('--------------------- 文本序列化  ---------------------')

tokenizer = create_Token(allText)


print('--------------------  标齐 sequence 长度  ------------------')

paded_seq = pad_sequences(tokenizer.texts_to_sequences(allText), maxlen=MAXLEN, padding='post', truncating='post')  # 对文本序列做填充或截断，保证每条文本序列长度一致

print('--------------------  获取 x & y  ------------------')

x_test = paded_seq[len(trainData):]
x_train = paded_seq[:len(trainData)]


y_train = get_label(trainData, x_train, tokenizer.index_word)



print('--------------------  获取 embedding matrix  ------------------')

emb_matrix = gen_emb_matrix(_tokenizer=tokenizer, all_text=allText)


print('--------------------  run skf  ------------------')

train_pred, test_pred, model = skf(em_matrix=emb_matrix, x_train=x_train, y_train=y_train, x_test=x_test)



print('--------------------  evalaute score  ------------------')


print('●验证集预测结果后处理')
entity_list, emotion_list = result_deal(train_pred, x_train, tokenizer.index_word, 0.7)

pred_data = pd.DataFrame(
    {
        CONFIG.KEY_ID: trainData[CONFIG.KEY_ID],
        'entity': entity_list,
        'emotion': emotion_list
    }
)

true_data = trainData[[CONFIG.KEY_ID, CONFIG.KEY_LABEL]]
true_data['entity'] = trainData[CONFIG.KEY_LABEL].apply(lambda x: list(x.keys()))
true_data['emotion'] = trainData[CONFIG.KEY_LABEL].apply(lambda x: list(x.values()))
true_data = true_data[[CONFIG.KEY_ID, 'entity', 'emotion']]

print('●计算验证集得分')
pred_data['emotion'] = pred_data['emotion'].apply(lambda x: x.split(','))
pred_data['entity'] = pred_data['entity'].apply(lambda x: x.split(','))
get_socre(true_data, pred_data)

print('●测试集预测结果后处理')
entity_list, emotion_list = result_deal(test_pred, x_test, tokenizer.index_word, 0.7)
pred_data = pd.DataFrame({CONFIG.KEY_ID: testData[CONFIG.KEY_ID], 'entity': entity_list, 'emotion': emotion_list})
pred_data[[CONFIG.KEY_ID, 'entity', 'emotion']].to_csv('/kaggle/working/result_sub.txt', sep='\t', index=None, header=None, encoding='utf-8')
