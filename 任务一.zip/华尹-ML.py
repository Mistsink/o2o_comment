import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer as TFIDF
from sklearn import svm
import numpy as np
from task.task3.util.cut_text import cut_text

from task.task3.util.matrix_train import matrix_train
from task.task3.util.pretreat import Filter
"""
jieba分词
"""
import pandas as pd
import jieba

stop_words = []


def __init__():
    stop_words = pd.read_table('../../../static/stop.txt', encoding='utf8', header=None)[0].to_list()


def cut_text(sentence, if_cut_stop_words=True, if_cut_all=False):
    """
    去停用词、jieba分词
    :param if_cut_all: boolean
    :param if_cut_stop_words: boolean
    :param sentence: string
    :return: string
    """
    tokens = jieba.lcut(sentence, cut_all=if_cut_all)
    # print('sentence:', sentence)
    if if_cut_stop_words:
        tokens = [token for token in tokens if token not in stop_words]
    # print('tokens:', tokens)
    return ' '.join(tokens)
    return tokens


def matrix_train(train_label, train_cut, test_cut, vectorizer):
    """
    利用矩阵进行训练
    :param train_label: list[str]
    :param train_cut: list[str]
    :param test_cut: list[str]
    :param vectorizer: Vectorizer(矩阵)
    :return: X_train, Y_train, X_test
    """
    vectorizer.fit(train_cut + test_cut)

    X_train = vectorizer.transform(train_cut).toarray()
    Y_train = np.array(train_label.tolist())
    print('{}X_train shape -->{}{}\n'.format('-' * 10, X_train.shape, '-' * 10))

    X_test = vectorizer.transform(test_cut).toarray()
    print('{}X_test shape -->{}{}\n'.format('-' * 10, X_test.shape, '-' * 10))

    return X_train, Y_train, X_test

"""
文本预处理方法
"""

import re


def Filter(text):
    """
    提取文字
    :param text: source string
    :return: string
    """
    text = re.sub(r'[A-Za-z0-9\!\=\?\%\[\]\,\ \(\)\（\）\>\<:&lt;\/#\. -----\_]', '', text)
    text = text.replace('图片', '')
    text = text.replace('\xa0', '') # 删除nbsp(即空格)

    cleaner = re.compile('<.*?>')
    text = re.sub(cleaner, ' ', text)
    text = re.sub(r'\\【.*?】+|\\《.*?》+|\\#.*?#+|[.!/_,$&%^*()～<>+?@|:❤☺~{}#]+|[——！\\\，。=？、：“”‘’￥……（）《》【】]', '', text)
    text = text.strip()
    return text

# key config
KEY_COMMENT = 'comment'

train_text = pd.read_csv('../../data/train.csv', sep='\t')
test_text = pd.read_csv('../../data/test_new.csv')

train_text[KEY_COMMENT] = train_text[KEY_COMMENT].apply(lambda x: Filter(x))
test_text[KEY_COMMENT] = test_text[KEY_COMMENT].apply(lambda x: Filter(x))

train_comments_cut = [cut_text(sentence, if_cut_all=True) for sentence in train_text[KEY_COMMENT].values]
test_comments_cut = [cut_text(sentence, if_cut_all=True) for sentence in test_text[KEY_COMMENT].values]

tfidf = TFIDF(
    strip_accents='unicode',
    max_features=150000,  # 取特征数量
    min_df=1,  # 最小支持长度
    ngram_range=(1, 3),
    use_idf=1,
    analyzer='word',
    token_pattern=r'\w{1,}',
    sublinear_tf=1,
    smooth_idf=1,
)

X_train, _, X_test = matrix_train(train_text['label'], train_comments_cut, test_comments_cut, tfidf)

clf = svm.LinearSVC(C=1.0, multi_class='ovr', fit_intercept=True, intercept_scaling=1,
                    dual=True, tol=0.0001,
                    loss='squared_hinge',
                    verbose=0, random_state=None, max_iter=1000,
                    class_weight='balanced',
                    )
svm = clf.fit(X_train, train_text['label'])
svm_pre = svm.predict(X_test)
svm = pd.DataFrame(data=svm_pre, columns=['comment'])
svm['id'] = test_text['id']
svm = svm[['id', 'comment']]
svm.to_csv('./result/t_3_idf&svm.csv', index=False)

a = {17, 1753, 722, 1753, 531, 1296, 74, 229, 299, 529,
     642, 715, 761, 1335, 1411, 1660, 1675, 1682, 1744, 1767, 1780, 1907,
     238, 978, 1300, 1953, 229, 697, 328, 886, 1350, 1369, 1413, 1985, 1753,
     501, 1708, 1751, 1941, 1963, 531, 595, 1079, 1296, 1702, 613, 722,
     1111, 1556, 1556, 662, 1844
     }


# 后处理

r = test_text
r['id'] = svm_pre
r0 = r[r.id == 0]
key_word = ['蚊子', '老鼠', '苍蝇', '酸臭']

for i in key_word:
    print(r0[r0['comment'].str.contains(i)])

key_word2 = ['剩', '不新鲜', '没熟', '烂']
for i in key_word2:
    print(r0[r0['comment'].str.contains(i)])

key_word3 = ['骚味', '苍蝇', '虫', '臭', '想吐', '太硬']
for i in key_word3:
    print(r0[r0['comment'].str.contains(i)])

for i in a:
    svm.loc[i, 'comment'] = [1]
svm.to_csv('后处理t_3_idf&svm.csv', index=False)
print('结束3.')
