import random
import re
import jieba
import pandas as pd
import numpy as np
from gensim.models import *
import torch
import numpy as np
from torchtext import data
from torchtext.vocab import Vectors
from gensim.models import KeyedVectors
import torch.nn as nn
from sklearn.metrics import f1_score

batch_size = 32
vector_size = 128

def gen_data(data_path, sep):
    return pd.read_csv(data_path, sep=sep, encoding='utf8')


def sent2id(batch_sent, word2id):  # 将一批句子转化成id的形式,并且取句子的最大长度为该批次句子的统一长度
    sents = []
    max_len = max([len(sen) for sen in batch_sent])

    for sent in batch_sent:
        sent_id = []
        for word in sent:
            sent_id.append(word2id.get(word, '<unk>'))
        while(len(sent_id) < max_len):
            sent_id.append(word2id["<PAD>"])
        sents.append(sent_id)
    return np.array(sents, dtype=np.int64)


def tokenize(text):
    text = re.sub(r'[A-Za-z0-9!=?%\[\], ()（）><:&lt;/#. -----_]', '', text)
    text = text.replace('图片', '')
    text = text.replace('\xa0', '')  # 删除nbsp(即空格)

    cleaner = re.compile('<.*?>')
    text = re.sub(cleaner, ' ', text)
    text = re.sub(r'\\【.*?】+|\\《.*?》+|\\#.*?#+|[.!/_,$&%^*()～<>+?@|:❤☺~{}#]+|[——！\\，。=？、：“”‘’￥……（）《》【】]', '', text)
    text = text.strip()
    return [word for word in jieba.cut(text) if word.strip()]


class LSTM(nn.Module):
    def __init__(self, embed_matrix, vocab_size, embedding_dim, hidden_dim, output_dim, n_layers, pad_idx):
        super().__init__()
        '''
            利用训练的词向量矩阵生成 embedding 层
        '''
        self.embedding = nn.Embedding(vocab_size, embedding_dim,
                                      padding_idx=pad_idx)  # Weight=[vocab_size,embedding_dim]
        self.embedding.weight.requires_grad = True
        self.embedding.weight.data.copy_(embed_matrix)
        '''
            此处为双向 lstm
        '''
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, batch_first=True, num_layers=n_layers,
                            bidirectional=True)
        '''
            注意这里的维度 ，经过双向处理后，维度增大一倍
        '''
        self.fc = nn.Linear(hidden_dim * 2, output_dim)
        self.dropout = nn.Dropout(0.3)

    def forward(self, text):
        output, (hidden, cell) = self.lstm(self.embedding(text))
        '''
            双向lstm处理后，进行适当的丢弃，防止过拟合
        '''
        output = self.dropout(output)
        hidden = torch.cat((hidden[-2, :, :], hidden[-1, :, :]), dim=1)
        out = torch.sigmoid(self.fc(hidden)).squeeze()
        return out



train_data = gen_data('./data/train.csv', sep="\t")
test_data = gen_data('./data/test_new.csv', sep=',')
result = gen_data('./data/sample.csv', sep=',')


all_comments = pd.concat([train_data['comment'], test_data['comment']])

word = set()

def f(text, word):
    for w in text:
        word.add(w)

all_comments.apply(f, args=(word, ))


def cutWord(content):
    return content.map(lambda x: [w for w in list(jieba.cut(x)) if len(w) != 1])

all_comments = cutWord(all_comments)


model = Word2Vec(size=vector_size, window=2,
                 min_count=1, workers=5, sg=0, iter=20)
model.build_vocab(all_comments)
model.train(all_comments, total_examples=model.corpus_count, epochs=model.iter)


index_word = model.wv.index2word
'''
    抽取出不在embeddddd.txt中的词
    并在头部插入一个 特殊词 以便后续填充时填为 0
'''
oov = list(word-set(index_word))
oov.insert(0, "<PAD>")

index_word = oov+index_word
word_index = dict(zip(index_word, np.arange(len(index_word)).tolist()))

emb_matrix = model.wv.vectors
embedding_dim = emb_matrix.shape[1]

def model_train(train_x, train_y):
    model.train()
    '''
        将梯度累积值清零
    '''
    optimizer.zero_grad()
    y_pred = model(train_x)
    '''
        计算损失值
    '''
    loss = criterion(y_pred, train_y)
    loss.backward()
    optimizer.step()
    return loss.item()



oov_emb = np.zeros((len(oov), embedding_dim))  # 不在embeddddd.txt中的词的向量初始化为0

emb_matrix = torch.from_numpy(np.vstack((oov_emb, emb_matrix)))
vocab_size = emb_matrix.shape[0]


def model_pred(valid_x):
    model.eval()
    with torch.no_grad():
        y_pred = model(valid_x)
        return y_pred



pad_index = word_index["<PAD>"]

train_data['comment'] = cutWord(train_data['comment'])

test_data['comment'] = cutWord(test_data['comment'])

'''
    随机抽取验证集，比例为 1: 4
'''
valid_data = train_data.sample(frac=0.2)
train_data = train_data[~train_data.index.isin(valid_data.index)]


model = LSTM(embed_matrix=emb_matrix,
             hidden_dim=256,
             output_dim=1,
             vocab_size=vocab_size,
             embedding_dim=embedding_dim,
             n_layers=1,
             pad_idx=pad_index)

optimizer = torch.optim.Adam(model.parameters(), lr=1e-4, weight_decay=1e-3)
criterion = nn.BCELoss()



for i in range(20):
    len_train = len(train_data)
    for i in range(0, len_train, batch_size):
        _train = train_data.iloc[i:len_train if i + batch_size > len_train else i + batch_size]
        train_x, train_y = _train['comment'], _train['label']
        train_x = torch.from_numpy(sent2id(train_x, word_index))
        train_y = torch.from_numpy(np.array(list(train_y), dtype=np.float32))
        loss = model_train(train_x, train_y)

    y_preds = []
    ys = []

    len_valid = len(valid_data)
    for i in range(0, len_valid, batch_size):
        _valid = valid_data.iloc[i:len_valid if i +
                                 batch_size > len_valid else i + batch_size]
        valid_x, valid_y = _valid['comment'], _valid['label']
        valid_x = torch.from_numpy(sent2id(valid_x, word_index))
        y_pred = torch.round(model_pred(valid_x)).numpy().tolist()
        '''
            添加到上层的预测数组中
        '''
        y_preds += y_pred
        ys += list(valid_y)
    f1 = f1_score(ys, y_preds)
    print("Validation Results - Epoch: {}  F1: {:.2f}".format(i + 1, f1))

model.eval()
'''
    进行预测
'''
y_preds = []
with torch.no_grad():
    len_test = len(test_data)
    for i in range(0, len_test, batch_size):
        _test = test_data.iloc[i:len_test if i + batch_size > len_test else i + batch_size]
        comment = sent2id(_test['comment'], word_index)
        comment = torch.from_numpy(comment)
        y_pred = model(comment)
        y_pred = torch.round(y_pred).numpy().tolist()
        '''
            添加到上层的预测数组中
        '''
        y_preds += y_pred

'''
    整理数据类型
'''
y_preds = y_preds.map(lambda x: int(x))
result['label'] = y_preds
result[['id', 'label']].to_csv('./result/result_LSTM_1.csv', index=None)
